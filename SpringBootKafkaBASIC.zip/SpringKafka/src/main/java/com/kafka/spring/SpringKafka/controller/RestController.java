package com.kafka.spring.SpringKafka.controller;

import com.kafka.spring.SpringKafka.model.Message;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@org.springframework.web.bind.annotation.RestController
@RequestMapping("/publish")
public class RestController {
    @Autowired
    KafkaTemplate KafkaTemplate;
    private static final String TOPIC="springBatch";
    @GetMapping("/string/{message}")
    public String publishStringMessage(@PathVariable("message") final String message){
        KafkaTemplate.send(TOPIC,message);
        return message+":  Message published to kafka";
    }
    @GetMapping("/json/{message}")
    public String publishJsonMessage(@PathVariable("message") final String data){
        Message message=new Message("RestService","Json",data);
        KafkaTemplate.send(TOPIC,message);
        return message.toString()+":  Message published to kafka";
    }


}
