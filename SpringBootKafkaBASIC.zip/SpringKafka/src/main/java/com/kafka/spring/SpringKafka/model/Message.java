package com.kafka.spring.SpringKafka.model;

public class Message {
    private String source;
    private String format;
    private String data;

    public Message(String source, String format, String data) {
        this.source = source;
        this.format = format;
        this.data = data;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getFormat() {
        return format;
    }

    public void setFormat(String format) {
        this.format = format;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    @Override
    public String toString() {
        return "Message{" +
                "source='" + source + '\'' +
                ", format='" + format + '\'' +
                ", data='" + data + '\'' +
                '}';
    }
}
