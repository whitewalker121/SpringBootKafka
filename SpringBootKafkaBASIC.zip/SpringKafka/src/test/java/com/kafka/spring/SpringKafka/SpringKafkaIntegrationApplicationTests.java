package com.kafka.spring.SpringKafka;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringKafkaIntegrationApplicationTests {

	@Test
	void contextLoads() {
	}

}
